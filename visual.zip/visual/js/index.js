
// //画饼状图
// var myChart1 = echarts.init(document.getElementById('pie'));
// option = {
//     // title : {
//     //     text: '某站点用户访问来源',
//     //     subtext: '纯属虚构',
//     //     x:'center'
//     // },
//     tooltip : {
//         trigger: 'item',
//         formatter: "{a} <br/>{b} : {c} ({d}%)"
//     },
//     legend: {
//         orient: 'vertical',
//         left: 'left',
//         data: ['直接访问','邮件营销','联盟广告','视频广告','搜索引擎']
//     },
//     series : [
//         {
//             name: '访问来源',
//             type: 'pie',
//             radius : '55%',
//             center: ['50%', '60%'],
//             data:[
//                 {value:335, name:'直接访问'},
//                 {value:310, name:'邮件营销'},
//                 {value:234, name:'联盟广告'},
//                 {value:135, name:'视频广告'},
//                 {value:1548, name:'搜索引擎'}
//             ],
//             itemStyle: {
//                 emphasis: {
//                     shadowBlur: 10,
//                     shadowOffsetX: 0,
//                     shadowColor: 'rgba(0, 0, 0, 0.5)'
//                 }
//             }
//         }
//     ]
// };
// myChart1.setOption(option);

$(document).ready(function () {


    //地图1的引用
    $.get('dist/BaoKangMap.json', function (chinaJson) {
        echarts.registerMap('BaoKang', chinaJson); // 注册地图
        var map1Chart = echarts.init(document.getElementById('map1'));
        var option = {
            geo: {
                map: 'BaoKang',

                itemStyle: {					// 定义样式
                    normal: {					// 普通状态下的样式
                        areaColor: '#4f9fcf',
                        borderColor: '#111'
                    },
                    // emphasis: {					// 高亮状态下的样式
                    //     areaColor: 'yellow'
                    // }
                }
            },
        }
        map1Chart.setOption(option);
    });




    $.get('dist/BaoKangMap.json', function (chinaJson) {
        echarts.registerMap('BaoKang', chinaJson); // 注册地图
        var mapChart = echarts.init(document.getElementById('map2'));

        var z=200;
        var myData = [
            // {name: '海门', value: [121.15, 31.89, 90]},    //经度、纬度、数值
            // {name: '鄂尔多斯', value: [109.781327, 39.608266, 120]},
            // {name: '招远', value: [120.38, 37.35, 142]},
            // {name: '舟山', value: [122.207216, 29.985295, 123]},
            {name: '标记点1', value: [ 111.047345, 31.423843, 123]},//经度、纬度、数值
            {name: '标记点2', value: [ 110.902345, 31.8679811835938, 10]},
            {name: '标记点3', value: [  111.123985625, 32.047202375, z]},
            // {name: '舟山', value: [122.207216, 29.985295, 200]},
            // {name: '舟山', value: [122.207216, 29.985295, z]},
        ]

        var option = {
            geo: {
                map: 'BaoKang',

                itemStyle: {					// 定义样式
                    normal: {					// 普通状态下的样式
                        areaColor: '#4f9fcf',
                        borderColor: '#111'
                    },
                    // emphasis: {					// 高亮状态下的样式
                    //     areaColor: 'yellow'
                    // }
                }
            },
            // visualMap: {
            //     min: 0, //最小
            //     max: 300,//最大
            //     splitNumber: 5,//共分5层
            //     color: ['#ff6300','#eac736','#50a3ba'],//颜色从高到低依次渐变
            //     textStyle: {
            //         color: '#fff',
            //         fontSize:8,
            //     }
            // },
            // backgroundColor: '#404a59',
            series: [
                {
                    name: '销量',
                    type: 'scatter',
                    coordinateSystem: 'geo',
                    data: myData // series数据内容
                }
            ]
        }
        mapChart.setOption(option);
    });


    //保康地图3的显示
    $.get('dist/BaoKangMap.json', function (chinaJson) {
        echarts.registerMap('geo', chinaJson);
        var chart = echarts.init(document.getElementById('map3'));
        chart.setOption({
            series: [{
                type: 'map',
                map: 'geo'
            }],
            regions: [//对不同的区块进行着色
                {
                    name: '保康县',
                    itemStyle: {
                        normal: {
                            areaColor: '#2b97df'
                        }
                    }
                }]
        });
    });



    //对元素div的显示和隐藏
    $("#top-click").click(function () {
        $("#append-div1").show();
        // $("#append-div1").toggle();
    });
    $("#append-btn").click(function () {
        // $("#append-div1").toggle();
        $("#append-div1").hide();
    })


});




//     //保康地图的显示  //地图1
//     $.get('dist/BaoKangMap.json', function (chinaJson) {
//         echarts.registerMap('geo', chinaJson);
//         var chart = echarts.init(document.getElementById('map1'));
//         chart.setOption({
//             series: [{
//                 type: 'map',
//                 map: 'geo'
//             }],
//             regions: [//对不同的区块进行着色
//                 {
//                     name: '保康县',
//                     itemStyle: {
//                         normal: {
//                             areaColor: '#2b97df'
//                         },
//                     }
//                 }]
//         });
//     });



//保康地图2的显示
// $.get('dist/BaoKangMap.json', function (chinaJson) {
//     echarts.registerMap('geo', chinaJson);
//     var chart = echarts.init(document.getElementById('map2'));
//     chart.setOption({
//         series: [{
//             type: 'map',
//             map: 'geo'
//         }],
//         regions: [//对不同的区块进行着色
//             {
//                 name: '保康县',
//                 itemStyle: {
//                     normal: {
//                         areaColor: '#2b97df'
//                     }
//                 }
//             }]
//     });
// });


