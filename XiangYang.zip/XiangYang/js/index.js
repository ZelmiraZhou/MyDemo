$(document).ready(function () {


    $(".topRightLi").hover(function () {
        $(this).children("ul").toggle();
        $(this).css("background-color","lightgray");
        $(this).find(".MenuTop a").each(function(){
            ($(this).css("color","blue"))
        })
    },function () {
        $(this).children("ul").hide();
        $(this).css("background-color","transparent");
        $(this).find(".MenuTop a").each(function(){
            ($(this).css("color","white"));
        })
    })

// //轮播的外边框
//     $.noConflict();
    jQuery('.zy-Slide').zySlide({ speed: 1000 })
// // .css('border', '0 solid blue')



    // $(".topRightLi>a").click(function () {
    //     var ulNode = $(this).next("ul");
    //     // ulNode.slideToggle();
    //
    //     // if(ulNode.css("display")=="none"){
    //     //     ulNode.css("display","block");
    //     // }else {
    //     //     ulNode.css("display","none");
    //     // }
    //
    //         ulNode.toggle(500);
    //
    //         // ulNode.slideDown();
    //         // ulNode.slideUp();
    //     })


        // $(".topRightLi").click(function () {
        //     $(this).children("ul").toggle();
        //     $(this).css("background-color","lightgray");
        //     $(this).find(".MenuTop a").each(function(){
        //        ($(this).css("color","blue"))
        //     })
        // });
        // $(".topRightLi").hover(function () {
        //     $(this).children("ul").hide();
        //     $(this).css("background-color","transparent");
        //     $(this).find(".MenuTop a").each(function(){
        //         ($(this).css("color","white"));
        //     })
        // });




});




// 停止自动播放
// function stop() {
//         // var _this = this
//         clearInterval(this.interval)
// }